import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-serviceebs',
  templateUrl: './serviceebs.component.html',
  styleUrls: ['./serviceebs.component.css']
})
export class ServiceebsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
