package com.ebs.model;
/**
 * @author Poonamchand Sahu
 * 
 * */
public enum AuthProvider {
	local, facebook, google
}
